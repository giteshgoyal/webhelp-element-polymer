# Google Web Components

A collection of web components for Google APIs & services. Built with [Polymer 1.0](https://www.polymer-project.org/1.0/).
