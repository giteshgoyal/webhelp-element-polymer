# google-feeds
Polymer element for the [Google Feeds API](https://developers.google.com/feed/)
