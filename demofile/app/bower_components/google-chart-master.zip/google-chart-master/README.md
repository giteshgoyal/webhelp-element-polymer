google-chart
============

[Google Charts API](https://developers.google.com/chart/) web components.

See https://elements.polymer-project.org/elements/google-chart
